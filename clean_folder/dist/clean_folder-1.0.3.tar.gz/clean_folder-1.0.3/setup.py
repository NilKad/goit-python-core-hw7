from setuptools import setup, find_namespace_packages

setup(
    name="clean_folder",
    version="1.0.3",
    # packages=find_packages(),
    packages=find_namespace_packages(),
    # long_description=open(join(dirname(__file__), 'README.txt')).read(),
    entry_points={'console_scripts': ['cleanfolder = clean_folder.clean']}
)
