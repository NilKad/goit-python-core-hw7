from setuptools import setup, find_namespace_packages

setup(
    name="clean_folder",
    version="1.0.4",
    packages=find_namespace_packages(),
)
